package Modelo.BDO;

import Modelo.*;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import com.db4o.query.Predicate;
import com.db4o.query.Query;
import java.util.ArrayList;
import java.util.Comparator;

public class CasoBDO {
   private ObjectContainer oc;
    
    public CasoBDO(ObjectContainer oc)
    {
        this.oc = oc;
    }
    
    public int  findMaxNroExp() throws Exception
    {
        Predicate<Caso> condicion=new Predicate<Caso>(){
            public boolean match(Caso c) {
                return true;
             }
        };
        Comparator<Caso> casoCmp = new Comparator<Caso>()
        {
              public int compare(Caso c1, Caso c2) {
                return Integer.parseInt(c2.getNroExp()) - Integer.parseInt(c1.getNroExp());
              }
        };
        
        ObjectSet resultado = oc.query(condicion,casoCmp); 
        if (resultado.hasNext())
        {
             Caso c =  (Caso) resultado.next();
             return Integer.parseInt(c.getNroExp());
        }    
        else
            return 0;
             
    }
    
    public void alta(Caso c) throws Exception
    {
        oc.store(c);
    }
    
    public Caso  consultarByNroExp(Caso c) throws Exception
    {
        ObjectSet resultado = oc.queryByExample(c);
        if (resultado.hasNext())
            return (Caso) resultado.next();
        return null;
    }
    
    public void baja(Caso c) throws Exception
    {
        oc.delete(c);
    }
    
    public ArrayList<Caso> consultaVariada(Caso c) throws Exception
    {
        ArrayList<Caso> lista = new ArrayList();
              
        ObjectSet resultado = oc.queryByExample(c);
        while (resultado.hasNext())
            lista.add((Caso) resultado.next());
        return lista;
    }
}
