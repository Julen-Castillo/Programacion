package Modelo.BDO;

import Modelo.Abogado;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.util.ArrayList;

public class AbogadoBDO {
    private ObjectContainer oc;
    
    public AbogadoBDO(ObjectContainer oc)
    {
        this.oc = oc;
    }
    
    public void alta(Abogado a) throws Exception
    {
        oc.store(a);
    }
    
    public Abogado consultarByDni(Abogado a) throws Exception
    {
        ObjectSet resultado = oc.queryByExample(a);
        if (resultado.hasNext())
            return (Abogado) resultado.next();
        return null;
    }
    
    public void baja(Abogado a) throws Exception
    {
        oc.delete(a);
    }
    
    public ArrayList<Abogado> consultaVariada(Abogado a) throws Exception
    {
        ArrayList<Abogado> lista = new ArrayList();
              
        ObjectSet resultado = oc.queryByExample(a);
        while (resultado.hasNext())
            lista.add((Abogado) resultado.next());
        return lista;
    }
    
}
