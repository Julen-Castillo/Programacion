
package Modelo.BDO;

import Modelo.Cliente;
import com.db4o.ObjectContainer;
import com.db4o.ObjectSet;
import java.util.ArrayList;

public class ClienteBDO {
    private ObjectContainer oc;
    
    public ClienteBDO(ObjectContainer oc)
    {
        this.oc = oc;
    }
    
    public void alta(Cliente cl) throws Exception
    {
        oc.store(cl);
    }
    
    public Cliente consultarByDni(Cliente cl) throws Exception
    {
        ObjectSet resultado = oc.queryByExample(cl);
        if (resultado.hasNext())
            return (Cliente) resultado.next();
        return null;
    }
    
    public void baja(Cliente cl) throws Exception
    {
        oc.delete(cl);
    }
    
    public ArrayList<Cliente> consultaVariada(Cliente cl) throws Exception
    {
        ArrayList<Cliente> lista = new ArrayList();
              
        ObjectSet resultado = oc.queryByExample(cl);
        while (resultado.hasNext())
            lista.add((Cliente) resultado.next());
        return lista;
    }
}
