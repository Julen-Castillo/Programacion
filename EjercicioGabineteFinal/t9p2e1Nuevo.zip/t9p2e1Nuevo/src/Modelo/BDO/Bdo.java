package Modelo.BDO;

import Modelo.*;
import com.db4o.Db4o;
import com.db4o.ObjectContainer;
import com.db4o.config.Configuration;

public class Bdo {
    
    private ObjectContainer con;
        
    public void abrirBD() throws Exception
    { 
        Configuration configuracion = Db4o.newConfiguration();
        configuracion.objectClass(Abogado.class).updateDepth(200);
        configuracion.objectClass(Cliente.class).updateDepth(200);
        configuracion.objectClass(Caso.class).updateDepth(200);
        con = Db4o.openFile(configuracion,"gabinete");
       
    }
    
    public void cerrarBD() throws Exception
    {    
        con.close();
    }

    public ObjectContainer getCon() 
    {
        return con;
    }
    
}
