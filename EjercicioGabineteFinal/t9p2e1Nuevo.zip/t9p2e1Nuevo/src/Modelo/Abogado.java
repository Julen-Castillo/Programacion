package Modelo;

import java.util.ArrayList;

public class Abogado extends Persona{
    
    private ArrayList<Caso> listaCasos;
    
    public Abogado(){}
    
    public Abogado(String d)
    {
        super(d);
    }
    
    public Abogado(String d, String n, String a, String dir)
    {
        super(d,n,a,dir);
        listaCasos = new ArrayList();
    }

    public ArrayList<Caso> getListaCasos() {
        return listaCasos;
    }
    
    public void setListaCasos(ArrayList<Caso> l) {
        listaCasos = l;
    }

    public void setCaso(Caso c) {
        if (listaCasos == null)
            listaCasos = new ArrayList();
        this.listaCasos.add(c);
    }
    
    
}
