package Modelo;

import java.util.ArrayList;

public class Cliente extends Persona{

    private String telefono;
    private ArrayList<Caso> listaCasos;

    public Cliente() {
    }

    public Cliente(String dni) {
        super(dni);
    }
    
    public Cliente(String d, String n, String a, String dir, String t)
    {
        super(d,n,a,dir);
        this.telefono = t;
        listaCasos = new ArrayList();
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public ArrayList<Caso> getListaCasos() {
        return listaCasos;
    }

    public void setCaso(Caso c){
        if (listaCasos == null)
            listaCasos = new ArrayList();
        this.listaCasos.add(c);
    }
    
    public void setListaCasos(ArrayList<Caso> l)
    {
        this.listaCasos = l;
    }
    
    public void eliminarCaso(Caso c)
    {
        listaCasos.remove(c);
    }
}
