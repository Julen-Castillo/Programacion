package Modelo.BDR;

import Modelo.Abogado;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import t9p2e1.Controlador;

public class AbogadoBDR {
    
    private static Bdr bdr;
    private static ResultSet resultado;
    
    public AbogadoBDR(){
        bdr = new Bdr();
    }

    public void alta(Abogado a) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "INSERT INTO abogado VALUES (?,?,?,?)";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,a.getDni());
        sentenciaPre.setString(2,a.getNombre());
        sentenciaPre.setString(3, a.getApellidos());
        sentenciaPre.setString(4, a.getDireccion());
       
        sentenciaPre.executeUpdate();
              
        // Cerrar la conexión
        bdr.cerrarCon();
    }
    
    public Abogado consultarByDni(Abogado a,boolean casos) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "Select * from abogado where dni = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,a.getDni());
      
        resultado = sentenciaPre.executeQuery();
        if (resultado.next())
            a = crearObjeto(casos);
        else
            a = null;
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return a;
    }
    
    public Abogado crearObjeto(boolean casos) throws Exception
    {
        Abogado a = new Abogado();
        
        a.setDni(resultado.getString("dni"));
        a.setNombre(resultado.getString("nombre"));
        a.setApellidos(resultado.getString("apellidos"));
        a.setDireccion(resultado.getString("direccion"));
        
        if (casos)
             a.setListaCasos(Controlador.getListaCasosAbogado(a.getDni()));
        return a;
    }
    
    public void baja(Abogado a) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "delete from abogado where dni = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,a.getDni());
      
        sentenciaPre.executeUpdate();
       
        bdr.cerrarCon();
    }
    
    public ArrayList<Abogado> consultaVariada(Abogado a) throws Exception
    {
        // construir la condición. Todo puede estar lleno o todo vacío
        if (a.getDni()==null && a.getNombre()==null && a.getApellidos()== null && a.getDireccion()==null)
            return consultaTodos();
        
        ArrayList<Abogado> lista = new ArrayList();
        String condicion="";
        if (a.getDni() != null)
        {
            condicion += "dni = \"" + a.getDni() + "\"";
        }
        if (a.getNombre() != null)
        {
            if ("".equals(condicion))
            {
                condicion += "nombre = \"" + a.getNombre() + "\"";
            }
            else
                condicion += " and nombre = \"" + a.getNombre() + "\"";
        }
        
        
        
        if (a.getApellidos() != null)
        {
            if ("".equals(condicion))
            {
                condicion += "apellidos = \"" + a.getApellidos() + "\"";
            }
            else
                condicion += " and apellidos = \"" + a.getApellidos() + "\"";
        }
         if (a.getDireccion() != null)
        {
            if ("".equals(condicion))
            {
                condicion += "direccion = \"" + a.getDireccion() + "\"";
            }
            else
                condicion += " and direccion = \"" + a.getDireccion() + "\"";
        }
            
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        Statement sentencia=bdr.getCon().createStatement();
        resultado = sentencia.executeQuery("select * from abogado where " + condicion);
        while (resultado.next())
            lista.add(crearObjeto(false));
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return lista;
    }
    
    public ArrayList<Abogado> consultaTodos() throws Exception
    {
        ArrayList<Abogado> lista = new ArrayList();
        
        bdr.conectar();
        
        Statement sentencia=bdr.getCon().createStatement();
        resultado = sentencia.executeQuery("select * from abogado");
        while (resultado.next())
            lista.add(crearObjeto(false));
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return lista;
    }
    
    public void modificar(Abogado a,String dniViejo) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "update abogado set dni = ?, nombre = ?, apellidos = ?, direccion = ? where dni = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,a.getDni());
        sentenciaPre.setString(2,a.getNombre());
        sentenciaPre.setString(3, a.getApellidos());
        sentenciaPre.setString(4, a.getDireccion());
        sentenciaPre.setString(5,dniViejo);
       
        sentenciaPre.executeUpdate();
              
        // Cerrar la conexión
        bdr.cerrarCon();
    }
}
