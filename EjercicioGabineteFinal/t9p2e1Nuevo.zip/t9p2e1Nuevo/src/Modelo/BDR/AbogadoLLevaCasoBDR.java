package Modelo.BDR;

import Modelo.Abogado;
import Modelo.Caso;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import t9p2e1.Controlador;

public class AbogadoLLevaCasoBDR {
    private static Bdr bdr;
    private static ResultSet resultado;
    
    public AbogadoLLevaCasoBDR(){
        bdr = new Bdr();
    }

    public void alta(Caso c) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        for (Abogado a: c.getListaAbogados())
        {
            String plantilla = "INSERT INTO abogado_lleva_caso VALUES (?,?)";
            PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
            sentenciaPre.setString(1,a.getDni());
            sentenciaPre.setString(2,c.getNroExp());
       
            sentenciaPre.executeUpdate();
        }
              
        // Cerrar la conexión
        bdr.cerrarCon();
    }
    
    public ArrayList<Caso> getListaCasosAbogado(Abogado a) throws Exception
    {
        ArrayList<Caso> lista = new ArrayList();
        
        bdr.conectar();
        
        String plantilla = "select * from  abogado_lleva_caso where abogado_dni = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,a.getDni());
         
        resultado = sentenciaPre.executeQuery();
        while (resultado.next())
        {
            String nroExp = resultado.getString("caso_expediente");
            lista.add(Controlador.getCasoAbogado(nroExp));
        }
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return lista;
    }
    
    public void baja(Caso c) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "delete from abogado_lleva_caso where caso_expediente = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,c.getNroExp());
      
        sentenciaPre.executeUpdate();
       
        bdr.cerrarCon();
    }
}
