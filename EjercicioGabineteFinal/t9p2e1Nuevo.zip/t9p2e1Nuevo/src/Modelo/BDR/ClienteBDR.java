
package Modelo.BDR;

import Modelo.Cliente;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import t9p2e1.Controlador;


public class ClienteBDR {
    
    private static Bdr bdr;
    private static ResultSet resultado;
    
    public ClienteBDR(){
        bdr = new Bdr();
    }

    public void alta(Cliente cl) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "INSERT INTO cliente VALUES (?,?,?,?,?)";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,cl.getDni());
        sentenciaPre.setString(2,cl.getNombre());
        sentenciaPre.setString(3, cl.getApellidos());
        sentenciaPre.setString(4, cl.getDireccion());
        sentenciaPre.setString(5,cl.getTelefono());
       
        sentenciaPre.executeUpdate();
              
        // Cerrar la conexión
        bdr.cerrarCon();
    }
    
    public Cliente consultarByDni(Cliente cl,boolean casos) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "Select * from cliente where dni = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,cl.getDni());
      
        resultado = sentenciaPre.executeQuery();
        if (resultado.next())
            cl = crearObjeto(casos);
        else
            cl = null;
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return cl;
    }
    
    public  Cliente crearObjeto(boolean casos) throws Exception{
        Cliente cl = new Cliente();
        
        cl.setDni(resultado.getString("dni"));
        cl.setNombre(resultado.getString("nombre"));
        cl.setApellidos(resultado.getString("apellidos"));
        cl.setDireccion(resultado.getString("direccion"));
        cl.setTelefono(resultado.getString("telefono"));
        
        // No siempre queremos los casos
        if (casos == true)
            cl.setListaCasos(Controlador.getListaCasosCliente(cl.getDni()));
        return cl;
    }
    
    public void baja(Cliente cl) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "delete from cliente where dni = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,cl.getDni());
      
        sentenciaPre.executeUpdate();
       
        bdr.cerrarCon();
    }
    
    public ArrayList<Cliente> consultaVariada(Cliente cl,boolean casos) throws Exception
    {
        // construir la condición. Todo puede estar lleno o todo vacío
        if (cl.getDni()==null && cl.getNombre()==null && cl.getApellidos()== null && cl.getDireccion()==null && cl.getTelefono()==null)
            return consultaTodos();
        
        ArrayList<Cliente> lista = new ArrayList();
        String condicion="";
        if (cl.getDni() != null)
        {
            condicion += "dni = \"" + cl.getDni() + "\"";
        }
        
        if (cl.getNombre() != null)
        {
            if ("".equals(condicion))
            {
                condicion += "nombre = \"" + cl.getNombre() + "\"";
            }
            else
                condicion += " and nombre = \"" + cl.getNombre() + "\"";
        }
        
        
        if (cl.getApellidos() != null)
        {
            if ("".equals(condicion))
            {
                condicion += "apellidos = \"" + cl.getApellidos() + "\"";
            }
            else
                condicion += " and apellidos = \"" + cl.getApellidos() + "\"";
        }
        
         if (cl.getDireccion() != null)
        {
            if ("".equals(condicion))
            {
                condicion += "direccion = \"" + cl.getDireccion() + "\"";
            }
            else
                condicion += " and direccion = \"" + cl.getDireccion() + "\"";
        }
         
         if (cl.getTelefono() != null)
        {
            if ("".equals(condicion))
            {
                condicion += "direccion = \"" + cl.getTelefono() + "\"";
            }
            else
                condicion += " and direccion = \"" + cl.getTelefono() + "\"";
        }
            
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        Statement sentencia=bdr.getCon().createStatement();
        resultado = sentencia.executeQuery("select * from cliente where " + condicion);
        while (resultado.next())
            lista.add(crearObjeto(casos));
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return lista;
    }
    
    public ArrayList<Cliente> consultaTodos() throws Exception
    {
        ArrayList<Cliente> lista = new ArrayList();
        
        bdr.conectar();
        
        Statement sentencia=bdr.getCon().createStatement();
        resultado = sentencia.executeQuery("select * from cliente");
        while (resultado.next())
            lista.add(crearObjeto(false));
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return lista;
    }
    
    public void modificar(Cliente cl,String dniViejo) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "update cliente set dni = ?, nombre = ?, apellidos = ?, direccion = ?, telefono = ? where dni = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,cl.getDni());
        sentenciaPre.setString(2,cl.getNombre());
        sentenciaPre.setString(3, cl.getApellidos());
        sentenciaPre.setString(4, cl.getDireccion());
        sentenciaPre.setString(5,cl.getTelefono());
        sentenciaPre.setString(6,dniViejo);
       
        sentenciaPre.executeUpdate();
              
        // Cerrar la conexión
        bdr.cerrarCon();
    }
    
}
