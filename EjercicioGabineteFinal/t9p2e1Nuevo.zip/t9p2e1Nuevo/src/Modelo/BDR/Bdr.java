package Modelo.BDR;

import java.sql.Connection;
import java.sql.DriverManager;

public class Bdr {
    
    private Connection con;
    
    public void conectar(){
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            String url="jdbc:mysql://localhost:3307/"+"gabinete";
            con = DriverManager.getConnection(url,"root","usbw");
        }
        catch(Exception e)
        {
            System.out.println("Problemas con la base de datos relacional");
            System.exit(0);
        }
    }
    
    public Connection getCon(){
        return con;
    }
    
    public void cerrarCon()throws Exception{
        con.close();
    }
    
}
