package Modelo.BDR;

import Modelo.Caso;
import Modelo.Cliente;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import t9p2e1.Controlador;

public class CasoBDR {
    
    private static Bdr bdr;
    private static ResultSet resultado;
    
    public CasoBDR(){
        bdr = new Bdr();
    }

    public int  findMaxNroExp() throws Exception
    {
        bdr.conectar();
        
        Statement sentencia=bdr.getCon().createStatement();
        resultado = sentencia.executeQuery("select max(nroExp)from caso");
        resultado.next();
        Integer n = resultado.getInt(1);
        bdr.cerrarCon();
        if (n == null)
            return 0;
        else
            return n;
    }
    
    public void alta(Caso c) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "INSERT INTO caso VALUES (?,?,?,?,?,?)";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,c.getNroExp());
        sentenciaPre.setString(2, c.getC().getDni());
        sentenciaPre.setDate(3,java.sql.Date.valueOf(c.getFechaInicio()));
        sentenciaPre.setDate(4, null);
        sentenciaPre.setString(5, c.getEstado().toString());
        sentenciaPre.setString(6,c.getDescripcion());
       
        sentenciaPre.executeUpdate();
              
        // Cerrar la conexión
        bdr.cerrarCon();
    }
    
    
    public Caso consultarByNroExp(Caso c)  throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "Select * from caso where nroExp = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,c.getNroExp());
      
        resultado = sentenciaPre.executeQuery();
        if (resultado.next())
            c = crearObjeto();
        else
            c = null;
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return c;
    }
    
    public Caso crearObjeto() throws Exception{
       Caso c = new Caso();
        
       c.setNroExp(resultado.getString("nroexp"));
       //c.setC(Controlador.getCliente(resultado.getString("Cliente_dni")));
       c.setFechaInicio(resultado.getDate("fechaInicio").toLocalDate());
       Date fechaF = resultado.getDate("fechaFin");
       if (fechaF != null)
             c.setFechaFin(fechaF.toLocalDate());
       c.setEstado(resultado.getString("estado").charAt(0));
       c.setDescripcion(resultado.getString("descripcion"));
       
       // lista de abogados???? Cuidado no entrar en bucle
       
        
        return c;
    }
    
    public void baja(Caso c) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "delete from caso where nroExp = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,c.getNroExp());
      
        sentenciaPre.executeUpdate();
       
        bdr.cerrarCon();
    }
    
    public ArrayList<Caso> consultaVariada(Caso c) throws Exception
    {
        // construir la condición. Todo puede estar lleno o todo vacío
        if (c.getNroExp()==null && c.getFechaInicio()==null && c.getFechaFin()== null && c.getEstado()==null && c.getDescripcion() == null)
            return consultaTodos();
        
        ArrayList<Caso> lista = new ArrayList();
        String condicion="";
        if (c.getNroExp() != null)
        {
            condicion += "nroExp = \"" + c.getNroExp()+ "\"";
        }
        if (c.getFechaInicio() != null)
        {
            if ("".equals(condicion))
            {
                condicion += "fechaInicio = \"" + c.getFechaInicio() + "\"";
            }
            else
                condicion += " and fechaInicio = \"" + c.getFechaInicio() + "\"";
        }
        
        if (c.getFechaFin()!= null)
        {
            if ("".equals(condicion))
            {
                condicion += "fechaFin = \"" + c.getFechaFin() + "\"";
            }
            else
                condicion += " and fechaFin = \"" + c.getFechaFin()+ "\"";
        }
        
        if (c.getEstado()!= null)
        {
            if ("".equals(condicion))
            {
                condicion += "estado = \"" + c.getEstado() + "\"";
            }
            else
                condicion += " and estado = \"" + c.getEstado() + "\"";
        }
        
        if (c.getDescripcion()!= null)
        {
            if ("".equals(condicion))
            {
                condicion += "descripcion = \"" + c.getDescripcion() + "\"";
            }
            else
                condicion += " and descripcion = \"" + c.getDescripcion() + "\"";
        }
            
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        Statement sentencia=bdr.getCon().createStatement();
        resultado = sentencia.executeQuery("select * from caso where " + condicion);
        while (resultado.next())
            lista.add(crearObjeto());
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return lista;
    }
    
    public ArrayList<Caso> consultaTodos() throws Exception
    {
        ArrayList<Caso> lista = new ArrayList();
        
        bdr.conectar();
        
        Statement sentencia=bdr.getCon().createStatement();
        resultado = sentencia.executeQuery("select * from caso");
        while (resultado.next())
            lista.add(crearObjeto());
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return lista;
    }
    
    public void modificar(Caso c) throws Exception
    {
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "update caso set Cliente_dni = ?, fechaInicio = ?, fechaFin= ?, estado = ?, descripcion = ? where nroExp = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,c.getC().getDni());
        sentenciaPre.setDate(2,java.sql.Date.valueOf(c.getFechaInicio()));
        sentenciaPre.setDate(3, null);
        sentenciaPre.setString(4, c.getEstado().toString());
        sentenciaPre.setString(5,c.getDescripcion());
        sentenciaPre.setString(6,c.getNroExp());
        sentenciaPre.executeUpdate();
              
        // Cerrar la conexión
        bdr.cerrarCon();
    }
    
    public ArrayList<Caso> consultaByDni(Caso c)  throws Exception
    {
        ArrayList<Caso> lista = new ArrayList();
        // abro conexión, ejecuto y cierro
        bdr.conectar();
        
        String plantilla = "Select * from caso where Cliente_dni = ?";
        PreparedStatement sentenciaPre = bdr.getCon().prepareStatement(plantilla);
        sentenciaPre.setString(1,c.getC().getDni());
      
        resultado = sentenciaPre.executeQuery();
        while (resultado.next())
        {
            lista.add(crearObjeto());
        }
       
              
        // Cerrar la conexión
        bdr.cerrarCon();
        return lista;
    }
    
}
