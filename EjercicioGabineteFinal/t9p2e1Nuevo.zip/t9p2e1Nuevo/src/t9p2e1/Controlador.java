
package t9p2e1;

import Excepciones.*;
import Modelo.*;
import Modelo.BDR.*;
import Modelo.BDO.*;

import Vista.VPrincipal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;

public class Controlador {

    // Variables globales
    private static Abogado a;
    private static Caso c;
    private static Cliente cl;
    private static ArrayList <Abogado> listaAbogados;
    private static ArrayList <Cliente> listaClientes;
    private static ArrayList<Caso> listaCasos;
    
    private static Bdo bdo;
    private static AbogadoBDO abogadoBDO;
    private static CasoBDO casoBDO;
    private static ClienteBDO clienteBDO;
    
    private static Bdr bdr;
    private static AbogadoBDR abogadoBDR;
    private static CasoBDR casoBDR;
    private static ClienteBDR clienteBDR;
    private static AbogadoLLevaCasoBDR abogadoLlevaCasoBDR;
    
    private static Vista.VPrincipal vp;
    
    private static Vista.Abogados.VAlta vaa;
    private static Vista.Abogados.VBorrar vab;
    private static Vista.Abogados.VModificar vam;
    private static Vista.Abogados.VConsultar vac;
    
    private static Vista.Clientes.VAlta vca;
    private static Vista.Clientes.VBorrar vcb;
    private static Vista.Clientes.VModificar vcm;
    private static Vista.Clientes.VConsultar vcc;
    
    private static Vista.Casos.VAlta vacs;
    private static Vista.Casos.VAsignarAbogados vasab;
    private static Vista.Casos.VBaja vbc;
    private static Vista.Casos.VConsultar vcac;
    private static Vista.Casos.VCerrar vcec;
    private static Vista.Casos.VModificar vmc;
    
    private static int posicion;
    
    public static void main(String[] args) {
       try
       { 
           // Crear Controladores para las bases de datos
            bdo = new Bdo();
            // Abro la base de datos orientada a objetos.
            bdo.abrirBD();
            abogadoBDO = new AbogadoBDO(bdo.getCon());
            casoBDO = new CasoBDO(bdo.getCon());
            clienteBDO=new ClienteBDO(bdo.getCon());
    
        
            abogadoBDR = new AbogadoBDR();
            casoBDR = new CasoBDR();
            clienteBDR = new ClienteBDR();
            abogadoLlevaCasoBDR = new AbogadoLLevaCasoBDR();
                    
            // Cedo el control a la primera ventana
            vp = new VPrincipal();
            vp.setVisible(true);
       }
       catch(Exception e)
       {
           System.out.println(e.getMessage());
       }
    }
    
    // Abogados
    public static void vistaAltaAbogado(){
        vaa = new Vista.Abogados.VAlta();
        vaa.setVisible(true);
    }
    
    public static void vistaBajaAbogado(){
        vab = new Vista.Abogados.VBorrar();
        vab.setVisible(true);
    }
    
    public static void vistaModificarAbogado(){
        vam = new Vista.Abogados.VModificar();
        vam.setVisible(true);
    }
    
    public static void vistaConsultarAbogado(){
        vac = new Vista.Abogados.VConsultar();
        vac.setVisible(true);
    }
    
    public static void volver(JFrame v)
    {
        v.dispose();
    }
    
     public static void terminar()
    {
        System.exit(0);
    }
    
    public static void altaAbogado(String dni, String nombre,String apellidos,String dir) throws Exception
    {
         // Creación de objetos a partir de los datos validados y entregados por la ventana
            a = new Abogado(dni,nombre,apellidos,dir);
           
         // Envío a la base de datos
            abogadoBDO.alta(a);
            abogadoBDR.alta(a);
    }
    
     public static void consultarAbogadoByDni(String dni,boolean casos)throws Exception{
        // busco abogado por dni.
        a = new Abogado(dni);
        
        // casos == true quiero recuperar los casos del abogado
        // casos == false no quiero los casos
        Abogado encontrado = abogadoBDR.consultarByDni(a,casos);
        encontrado = abogadoBDO.consultarByDni(a);
        // El orden importa. El último el de bdo
        if (encontrado == null)
            throw new AbogadoNoEncontradoException();
        a = encontrado;
        
    }
     
   public static String getDniAbogado(){
        return a.getDni();
    } 
    
    public static String getNombreAbogado(){
        return a.getNombre();
    }
    
    public static String getApellidosAbogado(){
        return a.getApellidos();
    }
    
    public static String getDireccionAbogado(){
        return a.getDireccion();
    }
    
    public static void bajaAbogado() throws Exception{
       abogadoBDO.baja(a);
       abogadoBDR.baja(a);
    }
    
    public static void consultarAbogado(String d, String n, String ap, String dir)throws Exception
    {
        // Consulto por dni y/o nombre y/o apellidos y/o direccion
        a = new Abogado();
        if (d.isEmpty())
            a.setDni(null);
        else
            a.setDni(d);
        if (n.isEmpty())
            a.setNombre(null);
        else
            a.setNombre(n);
        if (ap.isEmpty())
            a.setApellidos(null);
        else
            a.setApellidos(ap);
        if (dir.isEmpty())
            a.setDireccion(null);
        else
            a.setDireccion(dir);
        
        listaAbogados = abogadoBDR.consultaVariada(a);
        listaAbogados = abogadoBDO.consultaVariada(a);
        if (listaAbogados.size() == 0)
            throw new AbogadoNoEncontradoException();
        a = listaAbogados.get(0);
        posicion = 0;
        
    }
    
    public static boolean isHayMasAbogados()
    {
        return listaAbogados.size()-1 != posicion;
    }
    
    public static void siguienteAbogado()
    {
        posicion++;
        a = listaAbogados.get(posicion);
    }
    
    public static void modificarAbogado(String dni, String nombre,String apellidos,String dir) throws Exception
    {
        // Modificacion de objetos a partir de los datos validados y entregados por la ventana
        // guardo el "dniviejo" para la where
        String dniViejo = a.getDni();
        a.setDni(dni);
        a.setNombre(nombre);
        a.setApellidos(apellidos);
        a.setDireccion(dir);
        // Envío a la base de datos
        abogadoBDO.alta(a);
        abogadoBDR.modificar(a,dniViejo);
    }
    
    
    
       // Clientes
    public static void vistaAltaCliente(){
        vca = new Vista.Clientes.VAlta();
        vca.setVisible(true);
    }
    
    public static void vistaBajaCliente(){
        vcb = new Vista.Clientes.VBorrar();
        vcb.setVisible(true);
    }
    
    public static void vistaModificarCliente(){
        vcm = new Vista.Clientes.VModificar();
        vcm.setVisible(true);
    }
    
    public static void vistaConsultarCliente(){
        vcc = new Vista.Clientes.VConsultar();
        vcc.setVisible(true);
    }
    
    
    public static void altaCliente(String dni, String nombre,String apellidos,String dir,String tel) throws Exception
    {
         // Creación de objetos a partir de los datos validados y entregados por la ventana
            cl = new Cliente(dni,nombre,apellidos,dir,tel);
           
         // Envío a la base de datos
           clienteBDO.alta(cl);
           clienteBDR.alta(cl);
    }
    
     public static void consultarClienteByDni(String dni,boolean casos)throws Exception{
        // busco abogado por dni.
        cl = new Cliente(dni);
        
        Cliente encontrado = clienteBDR.consultarByDni(cl,casos);
        encontrado = clienteBDO.consultarByDni(cl);
        // El orden importa. El último el de bdo
        if (encontrado == null)
            throw new ClienteNoEncontradoException();
        cl = encontrado;
        
    }
     
   public static String getDniCliente(){
        return cl.getDni();
    } 
    
    public static String getNombreCliente(){
        return cl.getNombre();
    }
    
    public static String getApellidosCliente(){
        return cl.getApellidos();
    }
    
    public static String getDireccionCliente(){
        return cl.getDireccion();
    }
    
     public static String getTelefonoCliente(){
        return cl.getTelefono();
    }
    public static void bajaCliente() throws Exception{
      clienteBDO.baja(cl);
      clienteBDR.baja(cl);
    }
    
    public static void consultarCliente(String d, String n, String ap, String dir, String tel,boolean casos) throws Exception
    {
        // Consulto por dni y/o nombre y/o apellidos y/o direccion
      cl= new Cliente();
      
        if (d.isEmpty())
            cl.setDni(null);
        else
            cl.setDni(d);
        
        if (n.isEmpty())
            cl.setNombre(null);
        else
            cl.setNombre(n);
        
        if (ap.isEmpty())
            cl.setApellidos(null);
        else
            cl.setApellidos(ap);
        
        if (dir.isEmpty())
            cl.setDireccion(null);
        else
            cl.setDireccion(dir);
        
          if (tel.isEmpty())
            cl.setTelefono(null);
        else
            cl.setTelefono(tel);
        
        listaClientes= clienteBDR.consultaVariada(cl,casos);
        listaClientes = clienteBDO.consultaVariada(cl);
        if (listaClientes.size() == 0)
            throw new ClienteNoEncontradoException();
        cl = listaClientes.get(0);
        posicion = 0;
        
    }
    
    public static boolean isHayMasClientes()
    {
        return listaClientes.size()-1 != posicion;
    }
    
    public static void siguienteCliente()
    {
        posicion++;
        cl = listaClientes.get(posicion);
    }
    
    public static void modificarCliente(String dni, String nombre,String apellidos,String dir,String tel) throws Exception
    {
        // Modificacion de objetos a partir de los datos validados y entregados por la ventana
        // Lo de dniViejo también hay que añadirlo en abogado
         String dniViejo = cl.getDni();
         cl.setDni(dni);
         cl.setNombre(nombre);
         cl.setApellidos(apellidos);
         cl.setDireccion(dir);
         cl.setTelefono(tel);
         // Envío a la base de datos
         clienteBDO.alta(cl);
         clienteBDR.modificar(cl,dniViejo);
    }
    
    
    
    // Casos
    public static void vistaAltaCaso()
    {
        vacs = new Vista.Casos.VAlta();
        vacs.setVisible(true);
        
    }
    
    public static String asignarNroExp() throws Exception
    {
       Integer n =casoBDR.findMaxNroExp() + 1;
       n = casoBDO.findMaxNroExp() + 1;
       return n.toString();
    }
    
    public static boolean altaCaso( String nro,String fechaI,String estado,String des,String dni) throws Exception
    {
         // Creación de objetos a partir de los datos validados
        c = new Caso();
        c.setNroExp(nro);
           
         // Convertir String en LocalDate
         DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
         LocalDate dt = LocalDate.parse(fechaI,dtf);
         c.setFechaInicio(dt);
            
         // T = En trámite y A = Archivado
         c.setEstado('T');
         c.setDescripcion(des);
            
         cl = clienteBDO.consultarByDni(new Cliente(dni));
                    
         if (cl == null)
         {
                // No hay cliente con ese dni
                // ¿ Es un error? ¿ Insertamos?
                return false;
         }
         // Relaciones
         c.setC(cl);  
         cl.setCaso(c);
           
         // Envío a la base de datos
         casoBDO.alta(c);
         casoBDR.alta(c);
           
         return true;
    }
    
    public static String getCasosCliente()
    {
        String datos="";
        if (cl.getListaCasos().size() == 0)
            datos = " No hay casos";
        else
            for(Caso caso : cl.getListaCasos())
            {
                   datos += caso.toString() + "\n";
            }
        return datos;
    }
    
    public static String getCasosAbogado()
    {
        String datos="";
        
        if (a.getListaCasos().size() == 0)
            datos = "No ha casos";
        else
        {
            for(Caso caso : a.getListaCasos())
            {
               datos += caso.toString() + "\n";
            }
        }
        return datos;
    }
    
    public static ArrayList<Caso> getListaCasosAbogado(String d)throws Exception
    {
       return abogadoLlevaCasoBDR.getListaCasosAbogado(new Abogado(d));
    }
    
    public static Caso getCasoAbogado(String nroExp)throws Exception
    {
        return casoBDR.consultarByNroExp(new Caso(nroExp));
    }
    public static void vistaAsignarAbogados()
    {
        vasab = new Vista.Casos.VAsignarAbogados();
        vasab.setVisible(true);
    }
    
    public static void llenarListaAbogados(javax.swing.JList l) throws Exception
     {
         //listaAbogados = abogadoBDR.consultaTodos();
         listaAbogados = abogadoBDO.consultaVariada(new Abogado());
         
         DefaultListModel<String> model = new DefaultListModel<>();
  
         for(Abogado a: listaAbogados)
            model.addElement(a.getNombre() +" " + a.getApellidos());
         
         l.setModel(model);
     }
    
    public static void consultarCasoByNumero(String nroExp) throws Exception
    {
        c = new Caso(nroExp);
        Caso encontrado = casoBDR.consultarByNroExp(c);
        encontrado = casoBDO.consultarByNroExp(c);
        // El orden importa. El último el de bdo
        if (encontrado == null)
            throw new CasoNoEncontradoException();
        c = encontrado;
    }
    
    public static String getDatosCaso()
    {
        return c.toString();
    }
    
    public static String getDescripcionCaso()
    {
        return c.getDescripcion();
    }
    
    public static void asignarCaso(String numExp, int[] indices) throws Exception
    {
         
         ArrayList <Abogado> l = new ArrayList();
         
         for(int i: indices)
         {
             l.add(listaAbogados.get(i));
             listaAbogados.get(i).setCaso(c);
         }
         
         c.setListaAbogados(l);
         
         abogadoLlevaCasoBDR.alta(c);
         casoBDO.alta(c);
         // Al modificar la listaAbogados de abogados del caso se actualiza la tabla de abogado_lleva_caso
     }
    
    public static Cliente getCliente(String dni) throws Exception
    {
        return clienteBDR.consultarByDni(new Cliente(dni),false);
    }
    
    public static ArrayList<Caso> getListaCasosCliente(String dni) throws Exception
    {
        return casoBDR.consultaByDni(new Caso(new Cliente(dni)));
    }
    
    public static void bajaCaso() throws Exception
    {
        // Primero hay que borrar de abogado_LLeva_caso
        abogadoLlevaCasoBDR.baja(c);
        casoBDR.baja(c);
        casoBDO.baja(c);
    }
    
    public static void vistaBajaCaso()
    {
        vbc = new Vista.Casos.VBaja();
        vbc.setVisible(true);
    }
    
    public static void vistaCierreCaso()
    {
        vcec = new Vista.Casos.VCerrar();
        vcec.setVisible(true);
    }
    
    public static void vistaConsultaCasos()
    {
        vcac = new Vista.Casos.VConsultar();
        vcac.setVisible(true);
    }
    
    public static void cerrarCaso(String fecha) throws Exception
    {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate dt = LocalDate.parse(fecha,dtf);
        c.setFechaFin(dt);
        c.setEstado('A');
        casoBDR.modificar(c);
        casoBDO.alta(c);
    }
    
    public static void vistaModificarCaso()
    {
        vmc = new Vista.Casos.VModificar();
        vmc.setVisible(true);
    }
    
    public static void llenarCombo(javax.swing.JComboBox lista) throws Exception
    {
        // Lleno la combo con los casos no archivados
        listaCasos = casoBDR.consultaVariada(new Caso('T'));
        listaCasos = casoBDO.consultaVariada(new Caso('T'));
        for (int x=0; x < listaCasos.size();x++)
            lista.insertItemAt(listaCasos.get(x).getNroExp(), x);
    }
    
    public static void seleccionarCaso(int x)
    {
        c = listaCasos.get(x);
    }
    
    public static String getFechaCaso(){
        return c.getFechaInicio().toString();
    }
    
    public static String getDniClienteCaso(){
        return c.getC().getDni();
    }
    
    public static boolean actualizarCaso(String fecha, String des, String dni) throws Exception
    {
        // Elimino el cliente
        Cliente clienteViejo = c.getC();
        
        // Convertir String en LocalDate
         DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd");
         LocalDate dt = LocalDate.parse(fecha,dtf);
         c.setFechaInicio(dt);
            
         c.setDescripcion(des);
            
         cl = clienteBDO.consultarByDni(new Cliente(dni));
         cl = clienteBDR.consultarByDni(new Cliente(dni), false);
                    
         if (cl == null)
         {
                // No hay cliente con ese dni
                // ¿ Es un error? ¿ Insertamos?
                return false;
         }
         // Relaciones
         clienteViejo.eliminarCaso(c);
         
         c.setC(cl);  
         cl.setCaso(c);
           
         // Envío a la base de datos
         casoBDO.alta(c);
         casoBDR.modificar(c);
         return true;
           
    }
}