
package Vista.Casos;

import Excepciones.*;
import javax.swing.JOptionPane;
import t9p2e1.Controlador;


public class VConsultar extends javax.swing.JFrame {

    public VConsultar() {
       initComponents();
       setLocationRelativeTo(null);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bgTipoConsulta = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        rbCliente = new javax.swing.JRadioButton();
        rbAbogado = new javax.swing.JRadioButton();
        rbCaso = new javax.swing.JRadioButton();
        eTexto = new javax.swing.JTextField();
        tfDatoBusqueda = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        taSalida = new javax.swing.JTextArea();
        bSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Consulta de casos");

        bgTipoConsulta.add(rbCliente);
        rbCliente.setSelected(true);
        rbCliente.setText("Por cliente");
        rbCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbClienteActionPerformed(evt);
            }
        });

        bgTipoConsulta.add(rbAbogado);
        rbAbogado.setText("Por abogado");
        rbAbogado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbAbogadoActionPerformed(evt);
            }
        });

        bgTipoConsulta.add(rbCaso);
        rbCaso.setText("Por número de expediente");
        rbCaso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rbCasoActionPerformed(evt);
            }
        });

        eTexto.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        eTexto.setText("Dni  del cliente");
        eTexto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eTextoActionPerformed(evt);
            }
        });

        tfDatoBusqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfDatoBusquedaActionPerformed(evt);
            }
        });

        taSalida.setColumns(20);
        taSalida.setRows(5);
        taSalida.setEnabled(false);
        jScrollPane1.setViewportView(taSalida);

        bSalir.setText("Salir");
        bSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(128, 128, 128)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(rbCliente)
                                .addGap(14, 14, 14)
                                .addComponent(rbAbogado)
                                .addGap(74, 74, 74)
                                .addComponent(rbCaso))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(eTexto, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(45, 45, 45)
                                .addComponent(tfDatoBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 473, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(299, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(bSalir)
                .addGap(168, 168, 168))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(jLabel1)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbCliente)
                    .addComponent(rbAbogado)
                    .addComponent(rbCaso))
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(eTexto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(tfDatoBusqueda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 29, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(bSalir)
                .addGap(19, 19, 19))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rbAbogadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbAbogadoActionPerformed
       if (rbAbogado.isSelected())
       {
           eTexto.setText("Dni del abogado");
           tfDatoBusqueda.setText("");
           taSalida.setText("");
       }
    }//GEN-LAST:event_rbAbogadoActionPerformed

    private void rbCasoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbCasoActionPerformed
      if (rbCaso.isSelected())
      {
           eTexto.setText("Número de expediente");
           tfDatoBusqueda.setText("");
           taSalida.setText("");
       }
    }//GEN-LAST:event_rbCasoActionPerformed

    private void rbClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbClienteActionPerformed
        if (rbCliente.isSelected())
        {
            eTexto.setText("Dni del cliente");
            tfDatoBusqueda.setText("");
            taSalida.setText("");
       }
    }//GEN-LAST:event_rbClienteActionPerformed

    private void eTextoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eTextoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_eTextoActionPerformed

    private void bSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bSalirActionPerformed
        Controlador.volver(this);
    }//GEN-LAST:event_bSalirActionPerformed

    public void validarDni() throws Exception{}
    public void validarNroExp() throws Exception{}
    
    private void tfDatoBusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfDatoBusquedaActionPerformed
       try
       {
        if (rbCliente.isSelected())
        {
            validarDni();
            Controlador.consultarClienteByDni(tfDatoBusqueda.getText(),true);
            taSalida.setText(Controlador.getCasosCliente());
           
        }
        else
            if (rbAbogado.isSelected())
            {
                validarDni();
                Controlador.consultarAbogadoByDni(tfDatoBusqueda.getText(),true);
                taSalida.setText(Controlador.getCasosAbogado());
            }
            else
            {
                // Doy por hecho que es por número de expediente
                validarNroExp();
                Controlador.consultarCasoByNumero(tfDatoBusqueda.getText());
                taSalida.setText(Controlador.getDatosCaso());
            }
       }
       catch(ClienteNoEncontradoException e)
       {
           JOptionPane.showMessageDialog(this,"No hay ningún cliente con ese dni");
       }
       catch(AbogadoNoEncontradoException e)
       {
           JOptionPane.showMessageDialog(this,"No hay ningún abogado con ese dni");
       }
       catch(CasoNoEncontradoException e)
       {
           JOptionPane.showMessageDialog(this,"No hay ningún caso con ese número de expediente");
       }
       catch(Exception e)
       {
           JOptionPane.showMessageDialog(this,"Problemas: " + e.getMessage());
       }
    }//GEN-LAST:event_tfDatoBusquedaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VConsultar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VConsultar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VConsultar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VConsultar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VConsultar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton bSalir;
    private javax.swing.ButtonGroup bgTipoConsulta;
    private javax.swing.JTextField eTexto;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbAbogado;
    private javax.swing.JRadioButton rbCaso;
    private javax.swing.JRadioButton rbCliente;
    private javax.swing.JTextArea taSalida;
    private javax.swing.JTextField tfDatoBusqueda;
    // End of variables declaration//GEN-END:variables
}
