package Excepciones;

public class AbogadoNoEncontradoException extends Exception{
    
}
