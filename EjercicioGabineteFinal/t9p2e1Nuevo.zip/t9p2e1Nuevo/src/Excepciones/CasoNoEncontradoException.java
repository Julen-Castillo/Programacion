package Excepciones;

public class CasoNoEncontradoException extends Exception{
    
}
