
package Excepciones;

public class ClienteNoEncontradoException extends Exception{
    
}
