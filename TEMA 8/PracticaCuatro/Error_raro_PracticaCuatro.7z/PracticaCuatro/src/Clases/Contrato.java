
package Clases;

public class Contrato {
    
    private String descripcion;

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Contrato() {
    }

    public Contrato(String descripcion) {
        this.descripcion = descripcion;
    }
    
}
